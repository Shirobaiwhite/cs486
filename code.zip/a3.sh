#!/bin/bash
python ve.py
python ve.py | tee result.txt

